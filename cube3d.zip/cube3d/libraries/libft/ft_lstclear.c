/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstclear.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bde-luca <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/01/21 16:11:22 by bde-luca          #+#    #+#             */
/*   Updated: 2021/01/21 19:30:52 by bde-luca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstclear(t_list **lst, void (*del)(void *))
{
	t_list	*remove;

	if (!del || !lst || !*lst)
		return ;
	while (*lst)
	{
		remove = (*lst)->next;
		ft_lstdelone(*lst, del);
		*lst = remove;
	}
}
