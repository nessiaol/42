/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bde-luca <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/01/19 15:12:22 by bde-luca          #+#    #+#             */
/*   Updated: 2021/01/20 15:31:52 by bde-luca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	unsigned int		i;
	int					str_len;
	char				*to_return;
	char				support;

	if (s == NULL || f == NULL)
		return (NULL);
	str_len = ft_strlen(s);
	i = 0;
	if (!(to_return = (char *)malloc(sizeof(char) * str_len + 1)))
		return (NULL);
	while (s[i])
	{
		support = f(i, s[i]);
		to_return[i] = support;
		i++;
	}
	to_return[i] = '\0';
	return (to_return);
}
