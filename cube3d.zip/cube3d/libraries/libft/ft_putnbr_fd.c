/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bde-luca <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/01/18 18:07:01 by bde-luca          #+#    #+#             */
/*   Updated: 2021/01/18 19:17:52 by bde-luca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static	void	ft_output(int nb, int fd)
{
	int		i;
	int		a[11];

	i = 0;
	while (nb != 0)
	{
		a[i] = (nb % 10) + '0';
		nb = nb / 10;
		i++;
	}
	a[i] = '\0';
	i--;
	while (i >= 0)
	{
		write(fd, &a[i], 1);
		i--;
	}
}

void			ft_putnbr_fd(int nb, int fd)
{
	if (nb == -2147483648)
		write(fd, "-2147483648", 11);
	if (nb == 0)
		write(fd, "0", 1);
	if (nb < 0 && nb != -2147483648)
	{
		write(fd, "-", 1);
		nb = -nb;
	}
	if (nb > 0)
		ft_output(nb, fd);
}
